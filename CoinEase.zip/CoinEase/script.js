document.addEventListener("DOMContentLoaded", function() {
  var calculateButton = document.getElementById("calculate-button");
  var amountInput = document.getElementById("amount");


  calculateButton.addEventListener("click", function() {
      var amount = parseFloat(amountInput.value);
      var resultText = document.getElementById("resultText"); // Get the result element by its ID
    
      var changeText = "";

      var denominations = [5000, 2000, 1000, 500, 100, 50, 25];

      for (var i = 0; i < denominations.length; i++) {
          var denomination = denominations[i];
          var count = Math.floor(amount / denomination);
          if (count > 0) {
              changeText += count + " x " + denomination + " FCFA + ";
              amount %= denomination;
          }
      }
    
      if (amount > 0) {
          resultText.textContent = "Impossible de rendre la monnaie exacte avec les dénominations données.";
      } else {
          resultText.textContent = "Rendu de monnaie : " + changeText.slice(0, -2); // Remove the comma and space at the end
      }
  });
});